/*
  Filename: sort.hpp
  Author:   
  Course: 
  Date: 
  Assignment: 
  
  Description:
  
    Header file for templated sorting algorithms, specifically bubble
    sort (optimized), insertion sort, and selection sort.  Includes a
    'Statistics' data type for aggregating counts for swaps and
    comparisons.
*/

#ifndef SORTING_ALGORITHMS_HPP_
#define SORTING_ALGORITHMS_HPP_

#include <vector>

/**********************************************************/

struct Statistics
{
  // Default constructs swaps and compares to zero
  size_t numSwaps { 0 };
  size_t numCompares { 0 };
};

/**********************************************************/

template <typename T>
void
bubbleSort (std::vector<T>& v, Statistics& s)
{

}

/**********************************************************/

template <typename T>
void
insertionSort (std::vector<T>& v, Statistics& s)
{

}

/**********************************************************/

template <typename T>
void
selectionSort (std::vector<T>& v, Statistics& s)
{

}

#endif
