#include "fs.h"

// serves as an entry to the repl

int
main()
{
  fs_repl();
  return 0;
}
