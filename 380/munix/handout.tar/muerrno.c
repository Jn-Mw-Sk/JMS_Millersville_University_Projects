// File: muerrno.c
// Author: Chad Hogg
// A library for noting and retrieving errors.
// Part of CSCI380 munix lab.

#include "muerrno.h"

// The global variable into which our functions will write when errors occur.
int muerrno;