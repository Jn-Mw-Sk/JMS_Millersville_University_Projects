/*
 Filename   :
 Author     : Your Name
 Course     : 
 Date       : 
 Assignment : 
 Description: 
*/ 

// Include Directives
// **************************************************
#include <iostream>
#include <cstdlib>
// TODO: other includes go here

#include "Statistician.h"

// Using declarations
// **************************************************
using std::cout;
// TODO: any extra using declarations would go here

// Forward Declarations
// **************************************************

// TODO: any functions you implement AFTER main must be declared here


// Main
// **************************************************

int
main (int argc, char* argv[])
{
  return EXIT_SUCCESS;
}


// Function Implementations
// **************************************************

// TODO: any functions you call within main that are a part of this
// file must be implemented AFTER main
