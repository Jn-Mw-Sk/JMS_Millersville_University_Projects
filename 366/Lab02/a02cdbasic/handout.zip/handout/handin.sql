/* REPLACE THIS WITH YOUR NAME */
/* Lab 02: CD (basic) */

/* PROBLEM 1 BEGIN */
SELECT 'Replace this entire line with your answer';
/* PROBLEM 1 END */

/* PROBLEM 2 BEGIN */
SELECT 'Replace this entire line with your answer';
/* PROBLEM 2 END */

/* PROBLEM 3 BEGIN */
SELECT 'Replace this entire line with your answer';
/* PROBLEM 3 END */

/* PROBLEM 4 BEGIN */
SELECT 'Replace this entire line with your answer';
/* PROBLEM 4 END */

/* PROBLEM 5 BEGIN */
SELECT 'Replace this entire line with your answer';
/* PROBLEM 5 END */

/* PROBLEM 6 BEGIN */
SELECT 'Replace this entire line with your answer';
/* PROBLEM 6 END */

/* PROBLEM 7 BEGIN */
SELECT 'Replace this entire line with your answer';
/* PROBLEM 7 END */

/* PROBLEM 8 BEGIN */
SELECT 'Replace this entire line with your answer';
/* PROBLEM 8 END */

/* PROBLEM 9 BEGIN */
SELECT 'Replace this entire line with your answer';
/* PROBLEM 9 END */
